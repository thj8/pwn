#!/bin/sh

LD_PRELOAD=/home/user/libc.so.6 /home/user/vuln
